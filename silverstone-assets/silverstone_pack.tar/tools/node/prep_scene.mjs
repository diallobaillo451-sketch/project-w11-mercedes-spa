// Silverstone : repère de jeu (origine = ligne de départ, avant = -Z), découpe spatiale des gros objets,
// noms de matériaux canoniques du jeu (herbe / gravier / arbres / route / vibreurs), alpha MASK pour feuillages.
import { NodeIO, getBounds } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { flatten, transformMesh, prune } from '@gltf-transform/functions';
import sharp from 'sharp'; import fs from 'node:fs';
const [,, inp, outp, tfp] = process.argv;
const T = JSON.parse(fs.readFileSync(tfp, 'utf8'));
const c = Math.cos(T.phi), s = Math.sin(T.phi);
const tx = -(c * T.startX + s * T.startZ), ty = -T.y0, tz = s * T.startX - c * T.startZ;
const M = [c,0,-s,0, 0,1,0,0, s,0,c,0, tx,ty,tz,1];
const mul = (A, B) => { const R = new Array(16).fill(0); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) for (let k = 0; k < 4; k++) R[j*4+i] += A[k*4+i] * B[j*4+k]; return R };
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS);
const doc = await io.read(inp);
await doc.transform(flatten());
const root = doc.getRoot(), scene = root.listScenes()[0];
const MAP = {
  'asphalt.001': 'asph.001', 'asph_pitlane.001': 'asph.003', 'Curb_new.001': 'kerb_new.001', 'curb.001': 'kerb_new.002',
  'grass.001': 'GRASS', 'grass_NM.001': 'GRASS.001', 'top2.001': 'GRASS.002', 'top2_NM.001': 'GRASS.003',
  'sand_new.001': 'sand_new.001', 'sand-bordini.001': 'sand_new.002', 'trees.001': 'trees1_2022.001',
  'fences1.003': 'fences.003', 'fences1.001': 'fences.001',
  'barriers1.003': 'concrete-barrie-raw.003', 'barriers1.001': 'concrete-barrie-raw.001', 'jersey.003': 'concrete-barrie-raw.013', 'jersey.001': 'concrete-barrie-raw.011',
};
const MASKED = new Set(['trees.001', 'fences1.003', 'fences1.001', 'structures.003', 'structures.001']);
const FAR = new Set(['top2.001', 'top2_NM.001', 'top2_refl.001']);
const lin = v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4) };
async function meanLin(tex) { const b = await sharp(Buffer.from(tex.getImage())).resize(128, 128, { fit: 'fill' }).removeAlpha().raw().toBuffer(); let a = 0; for (let i = 0; i < b.length; i += 3) a += 0.2126 * lin(b[i]) + 0.7152 * lin(b[i+1]) + 0.0722 * lin(b[i+2]); return a / (b.length / 3) }
const report = [];
for (const m of root.listMaterials()) {
  const n = m.getName();
  if (MASKED.has(n)) { m.setAlphaMode('MASK'); m.setAlphaCutoff(0.5) }
  if (n === 'asphalt.001' || n === 'asph_pitlane.001') {
    const t = m.getBaseColorTexture(); const target = n === 'asphalt.001' ? 0.09 : 0.13;
    if (t) { const mean = await meanLin(t); const f = Math.min(1, target / mean); m.setBaseColorFactor([f, f, f, 1]); report.push([n, 'mean', +mean.toFixed(3), 'factor', +f.toFixed(3)]) }
    m.setRoughnessFactor(0.88); m.setMetallicFactor(0);
  }
  if (n === 'Curb_new.001' || n === 'curb.001') { m.setRoughnessFactor(0.88); m.setMetallicFactor(0) }
  if (/^(grass|top2|sand)/.test(n) ) { m.setMetallicFactor(0) }
}
console.log(JSON.stringify(report));
// ---- passe 1 : sommets en repère de jeu
const nodes = root.listNodes().filter(n => n.getMesh());
for (const node of nodes) {
  const mesh = node.getMesh(); const parents = mesh.listParents().filter(p => p.propertyType === 'Node');
  if (parents.length > 1) { console.log('mesh partagé', mesh.getName()); }
  let A = M; const mats = mesh.listPrimitives().map(p => p.getMaterial()?.getName() || '');
  if (mats.every(x => /^groove/.test(x))) A = mul([1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0.02,0,1], M);   // décalque au-dessus de la route (z-fighting)
  transformMesh(mesh, mul(A, node.getMatrix()));
  node.setTranslation([0,0,0]).setRotation([0,0,0,1]).setScale([1,1,1]);
}
// ---- passe 2 : découpe spatiale (cellules de 400 m) des primitives étendues
const CELL = 400, buf = root.listBuffers()[0];
let created = 0;
for (const node of nodes) {
  const mesh = node.getMesh(); const b = getBounds(node); const ext = Math.max(b.max[0]-b.min[0], b.max[2]-b.min[2]);
  const mats = mesh.listPrimitives().map(p => p.getMaterial()?.getName() || '');
  if (ext <= 520 || mats.some(x => FAR.has(x))) continue;
  for (const prim of mesh.listPrimitives()) {
    if (prim.getMode() !== 4 || !prim.getIndices()) continue;
    const pos = prim.getAttribute('POSITION').getArray(), idx = prim.getIndices().getArray();
    const groups = new Map();
    for (let t = 0; t < idx.length; t += 3) { const a = idx[t], b2 = idx[t+1], c2 = idx[t+2];
      const cx = (pos[3*a] + pos[3*b2] + pos[3*c2]) / 3, cz = (pos[3*a+2] + pos[3*b2+2] + pos[3*c2+2]) / 3;
      const key = Math.floor(cx / CELL) + '_' + Math.floor(cz / CELL); let g = groups.get(key); if (!g) groups.set(key, g = []); g.push(t) }
    const sems = prim.listSemantics(); const remap = new Int32Array(pos.length / 3);
    for (const [key, tris] of groups) {
      remap.fill(-1); let nv = 0; const ni = new Uint32Array(tris.length * 3);
      tris.forEach((t, k) => { for (let q = 0; q < 3; q++) { const v = idx[t+q]; if (remap[v] < 0) remap[v] = nv++; ni[k*3+q] = remap[v] } });
      const np = doc.createPrimitive().setMaterial(prim.getMaterial()).setMode(4);
      for (const sem of sems) { const at = prim.getAttribute(sem), src = at.getArray(), es = at.getElementSize(), dst = new src.constructor(nv * es);
        for (let v = 0; v < remap.length; v++) { const r = remap[v]; if (r >= 0) for (let e = 0; e < es; e++) dst[r*es+e] = src[v*es+e] }
        np.setAttribute(sem, doc.createAccessor(sem + key, buf).setType(at.getType()).setArray(dst).setNormalized(at.getNormalized())) }
      np.setIndices(doc.createAccessor('idx' + key, buf).setType('SCALAR').setArray(nv > 65535 ? ni : new Uint16Array(ni)));
      const nm = doc.createMesh((mesh.getName() || 'm') + '_' + key).addPrimitive(np);
      const nn = doc.createNode(node.getName() + '_c' + key).setMesh(nm); scene.addChild(nn); created++;
    }
  }
  scene.removeChild(node); node.dispose(); mesh.dispose();
}
console.log('nœuds créés par la découpe', created);
// ---- passe 3 : matériaux canoniques + noms de nœuds uniques
for (const m of root.listMaterials()) { const n = m.getName(); if (MAP[n]) m.setName(MAP[n]) }
let k = 0; for (const node of root.listNodes()) { if (!node.getMesh()) continue; const mats = node.getMesh().listPrimitives().map(p => p.getMaterial()?.getName() || '');
  const far = node.getMesh().listPrimitives().some(p => /^GRASS\.00[23]$/.test(p.getMaterial()?.getName() || '') || p.getMaterial()?.getName() === 'top2_refl.001');
  node.setName('n' + (k++) + '_' + (node.getName() || 'x').replace(/[^A-Za-z0-9_]/g, '') + (far ? '__far' : '')) }
await doc.transform(prune());
await io.write(outp, doc);
const tris = root.listMeshes().reduce((a, m) => a + m.listPrimitives().reduce((b, p) => b + (p.getIndices()?.getCount() ?? 0) / 3, 0), 0);
console.log('nœuds', root.listNodes().filter(n => n.getMesh()).length, 'triangles', tris, 'matériaux', root.listMaterials().length);
