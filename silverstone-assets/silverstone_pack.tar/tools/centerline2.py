import pickle, numpy as np
from PIL import Image, ImageDraw
from skimage.morphology import skeletonize, dilation, disk
from scipy.ndimage import convolve
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
G=pickle.load(open('geo.pkl','rb'))
x0,x1,z0,z1,S=-620.0,640.0,-1000.0,960.0,0.5
W=int((x1-x0)/S); H=int((z1-z0)/S)
im=Image.new('L',(W,H),0); d=ImageDraw.Draw(im)
for (nm,mat,V,F) in G:
    if mat not in ('groove.001','groove2.001','groove3.001'): continue
    P=np.stack([(V[:,0]-x0)/S,(V[:,2]-z0)/S],1)
    for t in P[F]: d.polygon([tuple(t[0]),tuple(t[1]),tuple(t[2])],fill=255)
M=dilation(np.array(im)>0,disk(4)); sk=skeletonize(M)
K=np.ones((3,3),int); K[1,1]=0
s=sk.copy()
for it in range(150):
    n=convolve(s.astype(int),K,mode='constant')*s; e=(n<=1)&s
    if not e.any(): break
    s[e]=False
pts=np.argwhere(s); idx=-np.ones(s.shape,int); idx[pts[:,0],pts[:,1]]=np.arange(len(pts))
rows=[];cols=[];w=[]
for dr,dc in [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]:
    r2=pts[:,0]+dr; c2=pts[:,1]+dc; ok=(r2>=0)&(r2<H)&(c2>=0)&(c2<W)
    j=np.full(len(pts),-1); j[ok]=idx[r2[ok],c2[ok]]; m=j>=0
    rows+=list(np.arange(len(pts))[m]); cols+=list(j[m]); w+=[np.hypot(dr,dc)]*m.sum()
A=coo_matrix((w,(rows,cols)),shape=(len(pts),len(pts))).tocsr()
WP_px=[(130,880),(210,745),(265,665),(340,658),(420,650),(500,610),(548,568),(583,590),(608,638),(632,628),(648,560),(630,510),(560,440),(480,370),(400,300),(320,232),(262,235),(243,288),(205,332),(172,300),(180,250),(230,180),(320,118),(450,100),(590,88),(650,105),(686,200),(693,330),(712,430),(740,520),(718,575),(740,650),(715,720),(650,790),(580,920),(520,1050),(440,1195),(385,1245),(330,1232),(285,1135),(240,1090),(172,1022),(130,1040),(80,1000),(72,955),(90,915)]
def px2idx(px,py):
    X=px*1.5-620; Z=py*1.5-1000
    c=(X-x0)/S; r=(Z-z0)/S
    dd=(pts[:,0]-r)**2+(pts[:,1]-c)**2; k=int(dd.argmin()); return k,np.sqrt(dd[k])*S
nodes=[]; 
for (px,py) in WP_px:
    k,dist=px2idx(px,py); nodes.append(k)
    if dist>12: print('far snap',px,py,round(dist,1),'m')
full=[]; tot=0
for a in range(len(nodes)):
    b=(a+1)%len(nodes)
    dist,pred=dijkstra(A,directed=False,indices=nodes[a],return_predecessors=True)
    path=[nodes[b]]
    while path[-1]!=nodes[a]:
        p=pred[path[-1]]
        if p<0: print('no path',a,b); break
        path.append(p)
    path=path[::-1]; L=dist[nodes[b]]*S; tot+=L
    full+=path[:-1]
    if L>400: print('long leg',a,'->',b,round(L),'m')
print('total length m',round(tot,1),'points',len(full))
P=pts[full]; X=x0+(P[:,1]+0.5)*S; Z=z0+(P[:,0]+0.5)*S
np.save('cl_raw.npy',np.stack([X,Z],1))
# overlay
base=Image.open('top_classes.png').convert('RGB'); dd=ImageDraw.Draw(base)
xy=[((x+620)/1.5,(z+1000)/1.5) for x,z in zip(X,Z)]
dd.line(xy+[xy[0]],fill=(255,255,0),width=2)
for i,(px,py) in enumerate(WP_px): dd.ellipse([px-3,py-3,px+3,py+3],outline=(255,0,255)); 
base.save('cl_overlay.png')
