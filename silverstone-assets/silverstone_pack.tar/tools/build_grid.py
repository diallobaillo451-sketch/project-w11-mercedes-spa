import numpy as np, json, math, time
from scipy.ndimage import gaussian_filter1d, median_filter, distance_transform_edt, map_coordinates
z=np.load('raster.npz'); CLS=z['CLS']; H=z['H']; WT=z['WT']; x0=float(z['x0']); z0=float(z['z0']); RES=float(z['res'])
CL=np.load('cl_centered.npy').astype(np.float64)
# --- départ : milieu de la voie des stands (Hamilton Straight)
S0=int(np.argmin((CL[:,0]+335)**2+(CL[:,1]-207)**2)); CL=np.roll(CL,-S0,axis=0); N=len(CL)
seg=np.hypot(*np.diff(np.vstack([CL,CL[:1]]),axis=0).T); L=float(seg.sum()); ds=L/N
print('N',N,'length',round(L,2),'ds',round(ds,5),'start orig',CL[0].round(1))
a=np.roll(CL,-2,axis=0); b=np.roll(CL,2,axis=0); T=a-b; T/=np.linalg.norm(T,axis=1,keepdims=True)
R=np.stack([-T[:,1],T[:,0]],1)   # droite (Y haut)
ND=361; D0=-45.0; DS=0.25
d=D0+DS*np.arange(ND)
PX=CL[:,0][:,None]+d[None,:]*R[:,0][:,None]; PZ=CL[:,1][:,None]+d[None,:]*R[:,1][:,None]
ix=np.clip(((PX-x0)/RES).astype(int),0,CLS.shape[1]-1); iz=np.clip(((PZ-z0)/RES).astype(int),0,CLS.shape[0]-1)
cls=CLS[iz,ix].astype(np.uint8); hh=H[iz,ix].astype(np.float64); wt=WT[iz,ix].astype(np.float64)
wall=(wt>-1e8)&(np.isnan(hh)|(wt>np.nan_to_num(hh,nan=-1e9)+0.35))
typ=cls.copy(); typ[typ==0]=4          # vide → herbe (sauf murs)
typ[wall]=7
# hauteur : trous remplis par le voisin valide le plus proche
nanm=np.isnan(hh)
if nanm.any():
    idx=distance_transform_edt(nanm,return_distances=False,return_indices=True); hh=hh[tuple(idx)]
jc=(ND-1)//2
cy_raw=np.median(hh[:,jc-6:jc+7],axis=1)
cy=gaussian_filter1d(cy_raw,3,mode='wrap'); cy-=cy[0]          # origine du repère : sol à la ligne de départ
rel=hh-(cy_raw[:,None]) ;  rel=hh-np.median(hh[:,jc-6:jc+7],axis=1)[:,None]
# relatif à cy lissé (le jeu ajoute cy[i] à h) :
rel=hh-(cy[:,None]+np.median(hh[:,jc-6:jc+7],axis=1)[0]-0) if False else hh-(gaussian_filter1d(cy_raw,3,mode='wrap')[:,None])
hcm=np.clip(np.round(rel*100),-4096,4095).astype(np.int32)
grid=(((hcm+4096)<<3)|typ.astype(np.int32)).astype(np.uint16)
# --- largeurs
def scan(sign):
    out=np.zeros(N); wallD=np.full(N,45.0)
    for i in range(N):
        row=typ[i]; j=jc; 
        while 0<=j+sign<ND and row[j+sign] in (1,3): j+=sign
        out[i]=abs(j-jc)*DS+0.125
        k=jc
        while 0<=k+sign<ND and row[k+sign]!=7: k+=sign
        if 0<=k+sign<ND: wallD[i]=abs(k+sign-jc)*DS
    return out,wallD
wr_raw,WR=scan(+1); wl_raw,WL=scan(-1)
wl=np.clip(median_filter(wl_raw,size=61,mode='wrap'),3.0,9.5); wr=np.clip(median_filter(wr_raw,size=61,mode='wrap'),3.0,9.5)
WL=median_filter(WL,size=5,mode='wrap'); WR=median_filter(WR,size=5,mode='wrap')
print('wl raw mean',wl_raw.mean().round(1),'wr raw mean',wr_raw.mean().round(1),' wl/wr clipped mean',wl.mean().round(2),wr.mean().round(2))
print('wallL median',np.median(WL).round(1),'wallR median',np.median(WR).round(1),'  % stations w/ wall<45 :',round(float((WL<45).mean()),2),round(float((WR<45).mean()),2))
print('type shares',{int(k):round(float(v)/typ.size,3) for k,v in zip(*np.unique(typ,return_counts=True))})
# --- repère jeu : origine = point de départ, avant = -Z
phi=math.atan2(T[0,1],T[0,0])+math.pi/2
c,s=math.cos(phi),math.sin(phi)
def xf(x,zz):
    xx=x-CL[0,0]; zz2=zz-CL[0,1]; return xx*c+zz2*s, -xx*s+zz2*c
GX,GZ=xf(CL[:,0],CL[:,1]); print('tangent start in game frame',np.round(xf(CL[0,0]+T[0,0],CL[0,1]+T[0,1]),3))
y0=float(gaussian_filter1d(cy_raw,3,mode='wrap')[0])
json.dump(dict(S0=S0,startX=float(CL[0,0]),startZ=float(CL[0,1]),phi=phi,y0=y0,L=L,N=N),open('transform.json','w'))
meta=dict(note="Grille physique alignée sur la ligne centrale, coords glTF (Y haut). cell=(hcm+4096)<<3|type, h relative à cy[i]",
  N=N,ND=ND,D0=D0,DSTEP=DS,ds=ds,length=L,types={"0":"vide","1":"asphalte","2":"vibreur","3":"tapis/peint","4":"herbe","5":"gravier/sable","6":"eau","7":"objet/mur"},
  cx=np.round(GX,3).tolist(),cy=np.round(cy,3).tolist(),cz=np.round(GZ,3).tolist(),wl=np.round(wl,2).tolist(),wr=np.round(wr,2).tolist(),wallL=np.round(WL,2).tolist(),wallR=np.round(WR,2).tolist())
import os; os.makedirs('out/track',exist_ok=True)
json.dump(meta,open('out/track/surface.json','w'),separators=(',',':'))
grid.astype('<u2').tofile('out/track/surface.bin')
print('surface.bin bytes',os.path.getsize('out/track/surface.bin'),'expected',N*ND*2,'; surface.json bytes',os.path.getsize('out/track/surface.json'))
np.save('grid_types.npy',typ); np.save('grid_rel.npy',rel)
