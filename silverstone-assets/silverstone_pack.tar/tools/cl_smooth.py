import numpy as np
from scipy.ndimage import gaussian_filter1d
P=np.load('cl_raw.npy')
def resample(P,ds):
    Q=np.vstack([P,P[:1]]); seg=np.hypot(*np.diff(Q,axis=0).T); c=np.concatenate([[0],np.cumsum(seg)]); L=c[-1]
    n=int(round(L/ds)); t=np.linspace(0,L,n,endpoint=False)
    return np.stack([np.interp(t,c,Q[:,0]),np.interp(t,c,Q[:,1])],1),L
Q,L0=resample(P,1.0); print('raw length',round(L0,1),'pts',len(Q))
for sig in (8,8):
    Q=np.stack([gaussian_filter1d(Q[:,0],sig,mode='wrap'),gaussian_filter1d(Q[:,1],sig,mode='wrap')],1)
    Q,L=resample(Q,1.0)
print('smoothed length',round(L,1),'pts',len(Q))
# curvature check
d1=np.gradient(Q,axis=0); d2=np.gradient(d1,axis=0); cur=(d1[:,0]*d2[:,1]-d1[:,1]*d2[:,0])/np.maximum((d1**2).sum(1)**1.5,1e-9)
print('min radius m',round(1/np.abs(cur).max(),1))
np.save('cl_smooth.npy',Q)
