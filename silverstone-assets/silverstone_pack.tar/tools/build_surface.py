import pickle, numpy as np, json, time, math
from numba import njit
from scipy.ndimage import gaussian_filter1d, median_filter, distance_transform_edt
t0=time.time()
G=pickle.load(open('geo.pkl','rb'))
CL=np.load('cl_smooth.npy').astype(np.float64)          # (N,2) x,z  (repère d'origine du modèle), sens du tour
N=len(CL)
# ---------- raster monde ----------
RES=0.25; PAD=55.0
x0=CL[:,0].min()-PAD; x1=CL[:,0].max()+PAD; z0=CL[:,1].min()-PAD; z1=CL[:,1].max()+PAD
nx=int((x1-x0)/RES)+1; nz=int((z1-z0)/RES)+1
print('raster',nx,'x',nz,'=',round(nx*nz/1e6,1),'M cellules')
CLS=np.zeros((nz,nx),np.uint8); H=np.full((nz,nx),np.nan,np.float32); WT=np.full((nz,nx),-1e9,np.float32)
@njit(cache=True)
def rast_ground(V,F,x0,z0,res,nx,nz,cls,val,H,CLS,flat_only):
    for t in range(F.shape[0]):
        a=V[F[t,0]];b=V[F[t,1]];c=V[F[t,2]]
        ux=b[0]-a[0];uy=b[1]-a[1];uz=b[2]-a[2];vx=c[0]-a[0];vy=c[1]-a[1];vz=c[2]-a[2]
        nxx=uy*vz-uz*vy; nyy=uz*vx-ux*vz; nzz=ux*vy-uy*vx
        ln=math.sqrt(nxx*nxx+nyy*nyy+nzz*nzz)
        if ln<1e-12: continue
        ny=abs(nyy)/ln
        if ny<(0.85 if flat_only else 0.5): continue
        area2=ux*vz-uz*vx
        if abs(area2)<1e-10: continue
        xmin=min(a[0],b[0],c[0]);xmax=max(a[0],b[0],c[0]);zmin=min(a[2],b[2],c[2]);zmax=max(a[2],b[2],c[2])
        i0=max(0,int((xmin-x0)/res-0.5));i1=min(nx-1,int((xmax-x0)/res+0.5));j0=max(0,int((zmin-z0)/res-0.5));j1=min(nz-1,int((zmax-z0)/res+0.5))
        for j in range(j0,j1+1):
            pz=z0+(j+0.5)*res
            for i in range(i0,i1+1):
                px=x0+(i+0.5)*res
                wx=px-a[0];wz=pz-a[2]
                l1=(wx*vz-wz*vx)/area2; l2=(ux*wz-uz*wx)/area2; l0=1.0-l1-l2
                if l0>=-1e-4 and l1>=-1e-4 and l2>=-1e-4:
                    H[j,i]=l0*a[1]+l1*b[1]+l2*c[1]; CLS[j,i]=val
@njit(cache=True)
def rast_wall(V,F,x0,z0,res,nx,nz,WT):
    for t in range(F.shape[0]):
        a=V[F[t,0]];b=V[F[t,1]];c=V[F[t,2]]
        for e in range(3):
            p=a if e==0 else (b if e==1 else c); q=b if e==0 else (c if e==1 else a)
            L=math.hypot(q[0]-p[0],q[2]-p[2]); n=int(L/(res*0.5))+1
            for k in range(n+1):
                f=k/n; x=p[0]+(q[0]-p[0])*f; z=p[2]+(q[2]-p[2])*f; y=p[1]+(q[1]-p[1])*f
                i=int((x-x0)/res); j=int((z-z0)/res)
                if i>=0 and i<nx and j>=0 and j<nz and y>WT[j,i]: WT[j,i]=y
        # intérieur (dessus des blocs)
        ux=b[0]-a[0];uz=b[2]-a[2];vx=c[0]-a[0];vz=c[2]-a[2]; area2=ux*vz-uz*vx
        if abs(area2)<1e-10: continue
        i0=max(0,int((min(a[0],b[0],c[0])-x0)/res));i1=min(nx-1,int((max(a[0],b[0],c[0])-x0)/res));j0=max(0,int((min(a[2],b[2],c[2])-z0)/res));j1=min(nz-1,int((max(a[2],b[2],c[2])-z0)/res))
        if (i1-i0)*(j1-j0)>4000: continue
        for j in range(j0,j1+1):
            pz=z0+(j+0.5)*res
            for i in range(i0,i1+1):
                px=x0+(i+0.5)*res; wx=px-a[0];wz=pz-a[2]
                l1=(wx*vz-wz*vx)/area2; l2=(ux*wz-uz*wx)/area2; l0=1.0-l1-l2
                if l0>=0 and l1>=0 and l2>=0:
                    y=max(a[1],max(b[1],c[1]))
                    if y>WT[j,i]: WT[j,i]=y
GROUND=[('top2.001',4,False),('top2_NM.001',4,False),('grass.001',4,False),('grass_NM.001',4,False),('sand_new.001',5,False),('sand-bordini.001',5,False),('tyreswall.001',1,True),('asphalt.001',1,False),('asph_pitlane.001',1,False),('curb.001',2,False),('Curb_new.001',2,False)]
for name,val,flat in GROUND:
    for (nm,mat,V,F) in G:
        if mat==name: rast_ground(V.astype(np.float64),F.astype(np.int64),x0,z0,RES,nx,nz,0,val,H,CLS,flat)
    print('ground',name,round(time.time()-t0,1),'s')
WALLS=['barriers1.003','barriers1.001','jersey.003','jersey.001','tyreswall.002','tyreswall.001','walls2.001','fences1.003','fences1.001']
for name in WALLS:
    for (nm,mat,V,F) in G:
        if mat==name: rast_wall(V.astype(np.float64),F.astype(np.int64),x0,z0,RES,nx,nz,WT)
    print('wall',name,round(time.time()-t0,1),'s')
np.savez_compressed('raster.npz',x0=x0,z0=z0,res=RES,CLS=CLS,H=H,WT=WT)
print('raster saved',round(time.time()-t0,1),'s')
