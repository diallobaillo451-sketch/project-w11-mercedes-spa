import pickle, sys
from glbread import load, meshes
j, mm = load(sys.argv[1])
ms = meshes(j, mm)
pickle.dump([(m["name"], m["mat"], m["V"], m["F"]) for m in ms], open("geo.pkl", "wb"), protocol=4)
