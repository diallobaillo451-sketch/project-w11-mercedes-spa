import struct, json, numpy as np
CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def load(path):
    f=open(path,'rb'); f.read(12)
    cl,_=struct.unpack('<I4s',f.read(8)); j=json.loads(f.read(cl))
    bl,_=struct.unpack('<I4s',f.read(8)); binoff=f.tell()
    import mmap
    mm=np.memmap(path,dtype=np.uint8,mode='r',offset=binoff,shape=(bl,))
    return j,mm
def acc(j,mm,i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
    dt=np.dtype(CT[a['componentType']]); n=NC[a['type']]; cnt=a['count']
    off=bv.get('byteOffset',0)+a.get('byteOffset',0); stride=bv.get('byteStride',n*dt.itemsize)
    if stride==n*dt.itemsize:
        arr=np.frombuffer(mm[off:off+cnt*n*dt.itemsize].tobytes(),dtype=dt).reshape(cnt,n)
    else:
        raw=np.frombuffer(mm[off:off+stride*cnt].tobytes(),dtype=np.uint8).reshape(cnt,stride)
        arr=np.ascontiguousarray(raw[:,:n*dt.itemsize]).view(dt).reshape(cnt,n)
    return arr
def local_mat(n):
    if 'matrix' in n: return np.array(n['matrix'],dtype=np.float64).reshape(4,4).T
    t=np.array(n.get('translation',[0,0,0]),float); q=np.array(n.get('rotation',[0,0,0,1]),float); s=np.array(n.get('scale',[1,1,1]),float)
    x,y,z,w=q; R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
    M=np.eye(4); M[:3,:3]=R*s; M[:3,3]=t; return M
def meshes(j,mm):
    """yield dict(node,name,mat,V,F,uv) in world space"""
    out=[]
    def walk(i,P):
        n=j['nodes'][i]; M=P@local_mat(n)
        if 'mesh' in n:
            for pi,pr in enumerate(j['meshes'][n['mesh']]['primitives']):
                V=acc(j,mm,pr['attributes']['POSITION']).astype(np.float64)
                V=(V@M[:3,:3].T+M[:3,3]).astype(np.float32)
                F=acc(j,mm,pr['indices']).reshape(-1,3).astype(np.uint32) if 'indices' in pr else np.arange(len(V),dtype=np.uint32).reshape(-1,3)
                uv=acc(j,mm,pr['attributes']['TEXCOORD_0']).astype(np.float32) if 'TEXCOORD_0' in pr['attributes'] else None
                mat=j['materials'][pr['material']]['name'] if 'material' in pr else None
                out.append(dict(node=i,name=n.get('name'),mat=mat,V=V,F=F,uv=uv))
        for c in n.get('children',[]): walk(c,M)
    for r in j['scenes'][j.get('scene',0)]['nodes']: walk(r,np.eye(4))
    return out
