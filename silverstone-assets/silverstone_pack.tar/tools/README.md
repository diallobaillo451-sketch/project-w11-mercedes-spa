# Silverstone : scripts de fabrication (ordre d'exécution)

Source : `silverstone_circuit_2024_layout.glb` (Dave Love, CC BY 4.0). Python 3 (numpy, scipy, numba, scikit-image, pillow), Node 22 (@gltf-transform/*, meshoptimizer, sharp).
Les points de passage de `centerline2.py` sont des positions approximatives lues sur la carte du tour ; le reste est automatique.

1. `glbread.py` : lecture du GLB (coordonnées monde) -> `geo.pkl` (voir l'en-tête de l'analyse, sérialisation des primitives).
2. `centerline2.py` : tour complet = chemin le plus court sur le squelette des marques de gomme (matériaux `groove*`) -> `cl_raw.npy`.
3. `cl_smooth.py` : rééchantillonnage 1 m et lissage -> `cl_smooth.npy`.
4. `build_surface.py` : raster monde 0,25 m (classes de sol, murs) -> `raster.npz`.
5. `recenter.py` : recentrage de la ligne sur la chaussée -> `cl_centered.npy`.
6. `build_grid.py` : `surface.json` + `surface.bin` + `transform.json` (repère de jeu : origine = départ, avant = -Z).
7. `node/prep_scene.mjs <glb> silverstone_final.glb transform.json` : repère de jeu, noms de matériaux du jeu, découpe spatiale.
8. `node/build_tiles.mjs silverstone_final.glb scene 12` : tuiles WebP + meshopt.
9. `make_track_ktx2.py` (dépôt : source/tools/circuit_pipeline) : textures KTX2.
