# Recentre la ligne (trajectoire de gomme) au milieu de la chaussée : décalage latéral = (droite − gauche)/2, mesuré sur la grille
import numpy as np
from scipy.ndimage import gaussian_filter1d
z=np.load('raster.npz'); CLS=z['CLS']; H=z['H']; WT=z['WT']; x0=float(z['x0']); z0=float(z['z0']); RES=float(z['res'])
CL=np.load('cl_smooth.npy').astype(np.float64)
def resample(P,ds=1.0):
    Q=np.vstack([P,P[:1]]); seg=np.hypot(*np.diff(Q,axis=0).T); c=np.concatenate([[0],np.cumsum(seg)]); L=c[-1]; n=int(round(L/ds)); t=np.linspace(0,L,n,endpoint=False)
    return np.stack([np.interp(t,c,Q[:,0]),np.interp(t,c,Q[:,1])],1),L
def edges(CL,cap=9.0):
    N=len(CL); a=np.roll(CL,-2,axis=0); b=np.roll(CL,2,axis=0); T=a-b; T/=np.linalg.norm(T,axis=1,keepdims=True); R=np.stack([-T[:,1],T[:,0]],1)
    d=np.arange(-12,12.0001,0.25); jc=len(d)//2
    PX=CL[:,0][:,None]+d[None,:]*R[:,0][:,None]; PZ=CL[:,1][:,None]+d[None,:]*R[:,1][:,None]
    ix=np.clip(((PX-x0)/RES).astype(int),0,CLS.shape[1]-1); iz=np.clip(((PZ-z0)/RES).astype(int),0,CLS.shape[0]-1)
    cls=CLS[iz,ix]; hh=H[iz,ix]; wt=WT[iz,ix]
    wall=(wt>-1e8)&(np.isnan(hh)|(wt>np.nan_to_num(hh,nan=-1e9)+0.35)); typ=np.where(wall,7,cls)
    ok=np.isin(typ,[1,3]); wl=np.zeros(N); wr=np.zeros(N)
    for i in range(N):
        j=jc
        while j+1<len(d) and ok[i,j+1]: j+=1
        wr[i]=(j-jc)*0.25
        j=jc
        while j-1>=0 and ok[i,j-1]: j-=1
        wl[i]=(jc-j)*0.25
    return np.minimum(wl,cap),np.minimum(wr,cap),R
for it in range(3):
    wl,wr,R=edges(CL)
    off=gaussian_filter1d((wr-wl)/2,12,mode='wrap'); off=np.clip(off,-6,6)
    CL=CL+off[:,None]*R
    CL=np.stack([gaussian_filter1d(CL[:,0],5,mode='wrap'),gaussian_filter1d(CL[:,1],5,mode='wrap')],1); CL,L=resample(CL,1.0)
    print('itération',it,'décalage moyen |off|',np.abs(off).mean().round(2),'max',np.abs(off).max().round(2),'longueur',round(L,1))
wl,wr,_=edges(CL); print('après recentrage : wl médiane',np.median(wl).round(2),'wr médiane',np.median(wr).round(2),' |wr-wl| moyen',np.abs(wr-wl).mean().round(2))
np.save('cl_centered.npy',CL)
